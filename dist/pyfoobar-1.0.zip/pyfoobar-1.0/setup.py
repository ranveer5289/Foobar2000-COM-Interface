from distutils.core import setup
setup(name='pyfoobar',
      version='1.0',
      description="Using foobar2000 through windows COM Interface",
      home_page="code.google.com/p/pyfoobar/",
      author="Ranveer Raghuwanshi",
      author_email="ranveer.raghu@gmail.com",
      py_modules=['pyfoobar'],
      )


